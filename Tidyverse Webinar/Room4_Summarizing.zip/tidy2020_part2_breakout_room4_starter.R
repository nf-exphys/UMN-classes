########################################################
# Into the Mud: Data Wrangling with R and the Tidyverse
#    Jeffrey K. Bye, Ph.D. & Ethan C. Brown, Ph.D.
#     Friday, December 11, 2020; 8:30 am–12:30 pm
########################################################

# Room 4: grouping and summarizing
library(tidyverse)
test <- read_csv("student_data_grouping.csv")
test # notice new column!

# Let's first pivot long 
test_long <- test %>% # and then...
  pivot_longer( # pivot it LONGER
    # cols = -c(Student_ID, Workshop), # every column EXCEPT Student_ID & Workshop
    cols = starts_with("Q"), # another way
    names_to = c("Question_Number", "Question_Type"), # TWO col names
    names_sep = "_", # so we have to tell it WHERE to split...
    values_to = "Score" # where do the values go? new col (default: 'value')
  )
test_long


