########################################################
# Into the Mud: Data Wrangling with R and the Tidyverse
#    Jeffrey K. Bye, Ph.D. & Ethan C. Brown, Ph.D.
#     Friday, December 11, 2020; 8:30 am–12:30 pm
########################################################

# 09:00 - 09:30 Morning Zoom synchronous -- 30 minute lecture

## OPEN PROJECT, OPEN FILE
# Notice the handy .csv file

# load tidyverse!
library(tidyverse)

# Read in data
test <- read_csv("student_data.csv")
# a benefit of RProjects is that if we keep everything in the same folder,
#   R can find the file *relative* to where the .RProj file is sitting
#   (i.e., inside its own folder)

# Examine data:
#   Note: this is completely fictional, random data
#     With the 'theme' that it's CEHD people answer test Qs about R
summary(test) # summarize
str(test) # structure

test
# oh no -- this data isn't tidy!
