########################################################
# Into the Mud: Data Wrangling with R and the Tidyverse
#    Jeffrey K. Bye, Ph.D. & Ethan C. Brown, Ph.D.
#     Friday, December 11, 2020; 8:30 am–12:30 pm
########################################################

# Room 3: recoding variables, including binning (e.g., strongly agree + agree)
library(tidyverse)
survey <- read_csv("r_survey.csv")

# Let's first pivot long only (not wide again)
#   The reason is that this will allow us to do all recoding in one column
#   Then we can pivot wide later
survey_long <- survey %>% 
  pivot_longer(
    cols = starts_with("P"), # pivot the columns that start with P (pre/post)
    names_to = c("Time", "Question"), # separate columns
    names_sep = "_", # separate at the _
    values_to = "Rating" # values into the Rating column
  ) 
