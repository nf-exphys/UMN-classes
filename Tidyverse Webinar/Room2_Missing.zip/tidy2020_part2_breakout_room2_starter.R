########################################################
# Into the Mud: Data Wrangling with R and the Tidyverse
#    Jeffrey K. Bye, Ph.D. & Ethan C. Brown, Ph.D.
#     Friday, December 11, 2020; 8:30 am–12:30 pm
########################################################

# Room 2: cleaning missing data (+ joining)
library(tidyverse)

# a slightly altered version of our student data file
test <- read_csv("student_data_missing.csv")
test

test_long <- test %>% 
  pivot_longer( # pivot it LONGER
    cols = starts_with("Q"), # every column that starts with Q (the questions)
    names_to = c("Question_Number", "Question_Type"), # TWO col names
    names_sep = "_", # so we have to tell it WHERE to split...
    values_to = "Score" # where do the values go? new col (default: 'value')
  )
test_long
